require("dotenv").config();
const cors = require("cors");
const express = require("express");
const session = require("express-session");
const database = require("./utils/database");
const checkSession = require("./middlewares/checksession");
const mysqlStore = require("express-mysql-session")(session);
const path = require('path');

const options = {
  connectionLimit: 30,
  password: "1234",
  user: "root",
  database: "btemp_profile",
  host: "localhost",
  createDatabaseTable: true,
};

const sessionStore = new mysqlStore(options);
const app = express();

// app.use(cors());
// app.use(
//   cors({
//     origin: ["http://localhost:5173", "http://localhost:5174","http://192.168.100.225:5173/"],
//     credentials: true,
//   })
// );

app.use(
  session({
    secret: process.env.SECRET,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      httpOnly: true, // Prevent JavaScript access to the session cookie
      secure: false,  // Set to `true` in production with HTTPS
      maxAge: 1000 * 60 * 60 * 24,  // 1 day expiration
    }
  })
);

// app.use(session({
//   secret: 'your-secret-key', // Set your session secret
//   resave: false,
//   saveUninitialized: true,
//   cookie: {
//     secure: false, // Change to true in production with HTTPS
//     httpOnly: true,
//   }
// }));


app.use(
  cors({
    origin: [
      process.env.LOCAL_CLIENT1,
      process.env.LOCAL_CLIENT2,
      
    ],
    credentials: true,
    methods: ["GET", "PUT", "POST", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);


// app.use(
//   cors({
//     origin: [
//       process.env.LIVE_CLIENT1,
//       process.env.LIVE_CLIENT2,
//       process.env.LIVE_CLIENT3
      
//     ],
//     credentials: true,
//     methods: ["GET", "PUT", "POST", "DELETE", "OPTIONS"],
//     allowedHeaders: ["Content-Type", "Authorization"],
//   })
// );
app.use(express.json());

// const fileDirectory = path.join(__dirname, 'C:/Users/user/OneDrive/Desktop/resources/chat');
// // Serve static files from an external directory
// app.use('/resources/chat',checkSession, express.static(fileDirectory));


// Serve static files from the public directory
const fileDirectory = 'C:/Users/user/OneDrive/Desktop/resources';
//const fileDirectory = '/home/btsccffu/resources';   //live static path
app.use('/resources', express.static(fileDirectory));



// Import Routers
const employee = require("./routes/employeeprofile");
const trackemployeeprofile = require("./routes/trackemployeeprofile");
const takerequest = require("./routes/customer/accept");
const trackticket = require("./routes/customer/trackticket");
const addJobLevel = require("./routes/internal/AddLevel");
const addBranch = require("./routes/internal/AddBranch");
const addOffice = require("./routes/internal/AddOffice");
const addTitle = require("./routes/internal/AddTitle");
const addEmployee = require("./routes/internal/AddEmployee");
const updateDefaultOffice = require("./routes/internal/UpdateDefaultOffice");
const insertMessage = require("./routes/customer/insertmessage");
const getConversation = require("./api/front_end_data/GetConversation");
const auth = require("./routes/internal/auth");
const authenticate = require("./routes/customer/authenticate");
const register = require("./routes/customer/register");
const setonline = require("./routes/customer/register");
const logout = require("./routes/internal/logout");
const userlogout = require("./routes/customer/userlogout");
const uploadImage = require("./routes/customer/uploadimage");
const uploadChatImage = require("./routes/customer/uploadchatimage");

// Import APIs

const getEmployees = require("./api/front_end_data/GetEmployees");
const getOffices = require("./api/front_end_data/GetOffices");
const getBranches = require("./api/front_end_data/GetBranches");
const getTitles = require("./api/front_end_data/GetTitles");
const getLevels = require("./api/front_end_data/GetLevel");
const getDefaultOffice = require("./api/front_end_data/GetDefaultOffice");
const getTickets = require("./api/front_end_data/GetTicketes");
const getAllTicketsForReport = require("./api/front_end_data/getallticketsforreport");
const getRequestById = require("./api/front_end_data/GetTicketById");
const getUserStats = require("./routes/internal/getuserstat");
const userstatus = require("./routes/customer/userstatus");
const getOfficeName = require("./api/front_end_data/GetOfficeName");
const getCateg = require("./api/front_end_data/GetCategories");
const getAttachedFiles = require("./api/front_end_data/GetAttachedFiles");
const getOfficeEmployees = require("./api/autheduser/getofficeemployees");

// Import Api for authenticated users
const profile = require("./api/authedcustomer/profile");
const getMyTickets = require("./api/autheduser/getmytickets");
const getMyActiveTickets = require("./api/autheduser/getmyactivetickets");
const esclateTkt = require("./api/autheduser/esclateticket");
const deleteTicket = require("./api/autheduser/deleterequest");
const assignToOffice = require("./api/autheduser/assignto");
const assignToFromAdmin = require("./api/autheduser/assigntoadmin");
const updatePassword = require("./api/autheduser/updatepassword");
const updateProfile = require("./api/autheduser/updateprofile");
const insertMessageManagment = require("./api/autheduser/insertMessageMan");
const closeTicket = require("./api/autheduser/closeticket");
const insertCategory = require("./api/autheduser/insertCategory");
const getMyExpired = require("./api/autheduser/getmyexpiredtickets");
const getMyExpireyHistory = require("./api/autheduser/getmyexpiryhistory");
const getMyOfficeTickets = require("./api/autheduser/getmyofficetickets");
const getMyChildOfficeTickets = require("./api/autheduser/getmychildofficetickets");
const analysMyOfficeTickets = require("./api/autheduser/analysmyofficetickets");
const getMyOfficeTicketsForReport = require("./api/autheduser/getmyofficetktsforreport");
const filterMyOfficeTicketsForReport = require("./api/autheduser/filtermyofficeticketsforreport");
const filterMyChildOfficeTicketsForReport = require("./api/autheduser/filtermychildofficeticketsforreport");
const getMyChildOfficeTicketsForReport = require("./api/autheduser/getmychildofficeticketsforreport");

const getSubOffices = require("./api/autheduser/getsuboffices");
const getSubOfficeTks = require("./api/autheduser/getsubofficetkts");
const markAsRead = require("./api/autheduser/markasread");
const uploadImageStaff = require("./routes/internal/Uploadchatimagestaff");
const assignToEmp = require("./api/autheduser/assignToemp");
const getProfile = require("./api/autheduser/getprofile");
// Import APIs for Tables

const tblGetBranches = require("./api/table_data/getbranches");
const tblGetOffices = require("./api/table_data/getoffices");
const tblGetLevels = require("./api/table_data/getlevel");
const tblGetTitles = require("./api/table_data/gettitle");
const lineGetTickets = require("./api/chart_data/getcharttickets");
const tblGetEmp = require("./api/table_data/getemp");

// Edit APIs

const editCategory = require("./routes/internal/Edit/EditCategory");
const editBranch = require("./routes/internal/Edit/EditBranch");
const editOffice = require("./routes/internal/Edit/EditOffice");
const editLevel = require("./routes/internal/Edit/EditLevel");
const editTitle = require("./routes/internal/Edit/EditTitle");
const editAccount = require("./routes/internal/Edit/EditAccount");
const resetPassword = require("./routes/internal/Edit/ResetPassword");

// Delete Apis
const deactivateAccount = require("./routes/internal/Delete/DeactivateAccount");
const activateAccount = require("./routes/internal/Delete/ActivateAccount");
const deleteBranchApi = require("./routes/internal/Delete/DeleteBranch");
const deleteCategoryApi = require("./routes/internal/Delete/DeleteCategory");
const deleteLevelApi = require("./routes/internal/Delete/DeleteLevel");
const deleteOfficeApi = require("./routes/internal/Delete/DeleteOffice");
const deleteTitleApi = require("./routes/internal/Delete/DeleteTitle");

app.get("/test", (req, res) => {
  res.status(200).json({ message: "working successfully" });
});

app.use("/employee", employee);
app.use("/trackemployeeprofile", trackemployeeprofile);
app.use("/getcategories", getCateg);
app.use("/takerequest", takerequest);
app.use("/trackticket", trackticket);
app.use("/insertmessage", insertMessage);
app.use("/insertmessageman", checkSession, insertMessageManagment);
app.use("/insertcategory", checkSession, insertCategory);
app.use("/getconvo", getConversation);
app.use("/closetkt", checkSession, closeTicket);
app.use("/addjoblevel", checkSession, addJobLevel);
app.use("/addbranch", checkSession, addBranch);
app.use("/addoffice", checkSession, addOffice);
app.use("/addtitle", checkSession, addTitle);
app.use("/addemp", checkSession, addEmployee);
app.use("/employees", checkSession, getEmployees);
app.use("/getoffices", checkSession, getOffices);
app.use("/getbranches", checkSession, getBranches);
app.use("/gettitles", checkSession, getTitles);
app.use("/getlevel", checkSession, getLevels);
app.use("/tblbranches", checkSession, tblGetBranches);
app.use("/tbloffices", checkSession, tblGetOffices);
app.use("/tbllevels", checkSession, tblGetLevels);
app.use("/tbltitle", checkSession, tblGetTitles);
app.use("/linechart", checkSession, lineGetTickets);
app.use("/tblemp", checkSession, tblGetEmp);
app.use("/updatedefaultOffice", checkSession, updateDefaultOffice);
app.use("/getdefaultoffice", checkSession, getDefaultOffice);
app.use("/gettickets", checkSession, getTickets);
app.use("/getallticketsforreport", checkSession, getAllTicketsForReport);
app.use("/getprofile", checkSession, getProfile);
app.use("/getreqbyid", checkSession, getRequestById);
app.use("/getofficename", checkSession, getOfficeName);
app.use("/auth", auth);  // employee/admin api
app.use("/authenticate", authenticate);  //customer/user login api
app.use("/register", register);  //customer/user register api
app.use("/setonline", setonline);
app.use("/userstat", getUserStats);
app.use("/userstatus", userstatus);
app.use("/getmytickets", checkSession, getMyTickets);
app.use("/getmyactivetickets", checkSession, getMyActiveTickets);
app.use("/profile", checkSession, profile);
app.use("/assigntktto", checkSession, assignToOffice);
app.use("/assignfromadmin", checkSession, assignToFromAdmin);
app.use("/esclateticket", checkSession, esclateTkt);
app.use("/deleterequest", checkSession, deleteTicket);
app.use("/updatepassword", checkSession, updatePassword);
app.use("/updateprofile", checkSession, updateProfile);
app.use("/logout", logout);
app.use("/userlogout", userlogout);
app.use("/editcategory", checkSession, editCategory);
app.use("/editbranch", checkSession, editBranch);
app.use("/editoffice", checkSession, editOffice);
app.use("/editlevel", checkSession, editLevel);
app.use("/edittitle", checkSession, editTitle);
app.use("/editaccount", checkSession, editAccount);
app.use("/deactivateacc", checkSession, deactivateAccount);
app.use("/activateacc", checkSession, activateAccount);
app.use("/deletebranch", checkSession, deleteBranchApi);
app.use("/deletecat", checkSession, deleteCategoryApi);
app.use("/deletelevel", checkSession, deleteLevelApi);
app.use("/deleteoffice", checkSession, deleteOfficeApi);
app.use("/deletetitle", checkSession, deleteTitleApi);
app.use("/resetpassword", checkSession, resetPassword);
app.use("/getmyexpired", checkSession, getMyExpired);
app.use("/myexpiryhistory", checkSession, getMyExpireyHistory);
app.use("/uploadimg", uploadImage);
app.use("/getattachements", getAttachedFiles);
app.use("/uploadchatimg", uploadChatImage);
app.use("/getmyofficetickets", checkSession, getMyOfficeTickets);
app.use("/getmychildofficetickets", checkSession, getMyChildOfficeTickets);
app.use("/analysmyofficetickets", checkSession, analysMyOfficeTickets);
app.use("/getmyofficeticketsforreport", checkSession, getMyOfficeTicketsForReport);
app.use("/filtermyofficeticketsforreport", checkSession, filterMyOfficeTicketsForReport);
app.use("/filtermychildofficeticketsforreport", checkSession, filterMyChildOfficeTicketsForReport);
app.use("/getmychildofficeticketsforreport", checkSession, getMyChildOfficeTicketsForReport);
app.use("/getsuboffices", checkSession, getSubOffices);
app.use("/getsubofficetkts", checkSession, getSubOfficeTks);
app.use("/markasread", checkSession, markAsRead);
app.use("/uploadimagestaff", checkSession, uploadImageStaff);
app.use("/getofficemp", checkSession, getOfficeEmployees);
app.use("/assigntoemp", checkSession, assignToEmp);

app.listen(process.env.PORT, (err) => {
  if (err) {
    return console.error(err);
  }
  console.log(`App is running on Port: ${process.env.PORT}`);
});
