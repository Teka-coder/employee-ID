// require('dotenv').config();
// const express = require('express');
// const mysql2 = require('mysql2/promise');


// // Create a connection pool
// const pool = mysql2.createPool({
//     host: process.env.HOST,
//     user: 'root',
//     password: '',
//     database: process.env.DATABASE,
//     waitForConnections: true,
//     connectionLimit: 10,
//     queueLimit: 0
//   });
//   console.log('Database pool created successfully'); 
//   module.exports = pool;