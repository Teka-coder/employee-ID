const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const database = require('../../utils/database');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');

// Set up multer storage
const weburl='https://qr.btsc-cfs.com/employee';
const uploadedemployee = `C:/Users/user/OneDrive/Desktop/resources/employee`;
const generatedemployee = `C:/Users/user/OneDrive/Desktop/resources/QR`;
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadedemployee); // Save uploaded images in the 'uploads' directory
  },
  filename: (req, file, cb) => {
    cb(null, uuidv4() + path.extname(file.originalname)); // Unique filename with original extension
  }
});
const upload = multer({ storage: storage });

const validateEmployeeName = (name) => {
    const regex = /^[A-Za-z\s]+$/; // Allow only letters and spaces
    return regex.test(name);
};
// Route to add employee
router.post("/", upload.single('emp_picture'), (request, response) => {
    console.log("I begin to add..");

    const {
        emp_fullname,
        emp_position,
        issued_date,
        staff_uniqueid,
        emp_phone,
        inserted_by,
        employed_date
    } = request.body;

    const emp_picture = request.file ? `employee/${request.file.filename}` : ''; // Get the file path if uploaded

    // Validate employee name
    if (!validateEmployeeName(emp_fullname)) {
        return response.status(400).json({ message: "Invalid employee name" });
    }

   

    // Generate unique filename for QR code
    const qrid=uuidv4();
    const qr_filename = qrid + '.png'; // Unique filename for each QR code
 
   // Generate QR code URL
 const qr_encode = `${weburl}/${qrid}`;
   
// Prepare the relative path for the QR code image
     const qr_picture = `employeeqrpic/${qr_filename}`;
     
    const qr_path = path.join(path.resolve(generatedemployee), qr_filename); // Save in the 'static' folder outside the project

    // Generate QR code and save as PNG file
    QRCode.toFile(qr_path, qr_encode, (err) => {
        if (err) {
            console.log("error happend "+err)
            return response.status(500).json({ message: "Error generating QR code" });
        }


        // Parameterized query to insert employee data into the database
        const sql = `
            INSERT INTO employee (emp_fullname, emp_position, issued_date, staff_uniqueid, emp_phone, emp_picture, qr_encode, qr_picture, inserted_by, employed_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        
        const values = [
            emp_fullname,
            emp_position,
            issued_date,
            staff_uniqueid,
            emp_phone,
            emp_picture,
            qr_encode,
            qr_picture,
            inserted_by,
            employed_date
        ];

        // Insert employee into the database
        database.query(sql, values, (error, result) => {
            if (error) {
                console.log("Failed to insert");
                return response.status(500).json({ message: "Failed to insert employee" });
            } else {
                console.log("Successful");
                response.status(200).json({ message: "Employee added successfully", recentEmployee: result });
            }
        });
    });
});

module.exports = router;
