const express = require('express')
const { deleteBranch } = require('../../../api/helpers/databaseHelpers')
const router = express.Router()
router.use(express.json())

router.post('/', (request,response)=>{
    deleteBranch(request.body.id).then(result =>{
        if(result){
            response.status(200).json({"message":"successfull"})
        }else{
            response.status(500).json({"message":"failed"})
        }
    }).catch(error => response.status(500).json({"message":"failed"}))
})

module.exports = router